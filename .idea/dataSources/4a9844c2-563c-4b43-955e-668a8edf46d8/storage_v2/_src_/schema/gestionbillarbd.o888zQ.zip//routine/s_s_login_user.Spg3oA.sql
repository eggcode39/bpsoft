create procedure s_s_login_user(IN vuser_nickname varchar(40))
  BEGIN
Select * from user u inner join person p on u.id_person = p.id_person inner join role r on r.id_role = u.id_role where u.user_nickname = vuser_nickname collate utf8_spanish_ci;
END;

